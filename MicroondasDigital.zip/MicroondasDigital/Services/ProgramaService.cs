﻿using MicroondasDigital.Entities;
using System.Collections.Generic;

namespace MicroondasDigital.Services
{
    public class ProgramaService
    {
        private readonly JsonService _json = new JsonService();

        public List<ProgramaAquecimento> ObterProgramasPadrao()
        {
            return new List<ProgramaAquecimento>
            {
                new ProgramaAquecimento
                {
                    Nome = "Pipoca",
                    Alimento = "Pipoca (micro-ondas)",
                    Tempo = 180,
                    Potencia = 7,
                    Caractere = '*',
                    Instrucoes = "Observar o intervalo entre os estouros.",
                    Personalizado = false,
                    PermiteAdicionarTempo = false
                },

                new ProgramaAquecimento
                {
                    Nome = "Leite",
                    Alimento = "Leite",
                    Tempo = 300,
                    Potencia = 5,
                    Caractere = '~',
                    Instrucoes = "Cuidado com líquidos aquecidos.",
                    Personalizado = false,
                    PermiteAdicionarTempo = false
                },

                new ProgramaAquecimento
                {
                    Nome = "Carnes",
                    Alimento = "Carne",
                    Tempo = 840,
                    Potencia = 4,
                    Caractere = '#',
                    Instrucoes = "Virar o alimento na metade.",
                    Personalizado = false,
                    PermiteAdicionarTempo = false
                },

                new ProgramaAquecimento
                {
                    Nome = "Frango",
                    Alimento = "Frango",
                    Tempo = 480,
                    Potencia = 7,
                    Caractere = '@',
                    Instrucoes = "Virar o alimento na metade.",
                    Personalizado = false,
                    PermiteAdicionarTempo = false
                },

                new ProgramaAquecimento
                {
                    Nome = "Feijão",
                    Alimento = "Feijão",
                    Tempo = 480,
                    Potencia = 9,
                    Caractere = '%',
                    Instrucoes = "Aquecer destampado.",
                    Personalizado = false,
                    PermiteAdicionarTempo = false
                }
            };
        }

        public List<ProgramaAquecimento> ObterTodos()
        {
            var lista = ObterProgramasPadrao();

            lista.AddRange(_json.Ler());

            return lista;
        }
    }
}